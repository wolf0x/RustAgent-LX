# TSecBench Challenges API 接口详情

> 完整参考：平台下发的 `CHALLENGES_API.md`（本文为其精简速查版）。
> 所有接口路径前缀：`/openapi/v1/challenges`。

## 认证

所有接口通过 HTTP 请求头 `BENCHMARK_TOKEN` 鉴权：

```http
GET /openapi/v1/challenges HTTP/1.1
Host: <platform-host>
BENCHMARK_TOKEN: <uuid>
```

token 无效/缺失 → `404 task_not_found`。

## 接口一览

| # | 方法 | 路径 | 作用 |
|---|------|------|------|
| 1 | GET | `/openapi/v1/challenges` | 获取题目列表及作答进度 |
| 2 | POST | `/openapi/v1/challenges/start?unique_code={code}` | 启动题目容器 |
| 3 | GET | `/openapi/v1/challenges/hint?unique_code={code}` | [可选] 获取提示（扣分） |
| 4 | POST | `/openapi/v1/challenges/submit` | 提交 flag |
| 5 | POST | `/openapi/v1/challenges/close?unique_code={code}` | 关闭容器 |

---

## 1. 列出题目

```
GET /openapi/v1/challenges
```

请求参数：无（仅 header 认证）。

成功响应 `200`（数组）：

```json
[
  {
    "unique_code": "web_sql_injection_01",
    "description": "通过 SQL 注入获取管理员凭证并读取 flag",
    "difficulty": "easy",
    "level": 1,
    "total_score": 100,
    "flag_count": 2,
    "correct_flag_count": 1,
    "is_completed": false,
    "container_status": "available",
    "container_addr": ["10.0.1.5:8080"]
  }
]
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `unique_code` | string | 题目唯一标识，后续接口均用此值 |
| `description` | string \| null | 题目描述（可能为空） |
| `difficulty` | string | easy / medium / hard |
| `level` | int | 题目关卡 |
| `total_score` | int | 该题满分（所有 flag 分数之和） |
| `flag_count` | int | 该题 flag 总数 |
| `correct_flag_count` | int | 已正确提交的 flag 数 |
| `is_completed` | bool | 是否全部通关 |
| `container_status` | string | `pending`（启动中）/ `available`（就绪可访问）/ `stop_pending`（停止中）/ `stopped`（已停止） |
| `container_addr` | array[string] | 容器直连地址 `IP:端口`；**仅当 `container_status == available` 时有值**，其余一律 `[]`，需 VPN 直连 |

业务异常：无额外异常（仅 `task_not_found`、`invalid_state`）。

---

## 2. 启动题目容器

```
POST /openapi/v1/challenges/start?unique_code={unique_code}
```

| 参数 | 位置 | 类型 | 必填 | 说明 |
|------|------|------|------|------|
| `unique_code` | query | string | 是 | 题目唯一标识 |

成功响应 `200`：

```json
{
  "unique_code": "web_sql_injection_01",
  "container_addr": ["10.0.1.5:8080"]
}
```

业务异常：

| HTTP | code | 触发场景 |
|------|------|----------|
| 404 | `challenge_not_found` | `unique_code` 不存在于当前任务 |
| 409 | `invalid_state` | 活跃题目实例数已达上限（最多 3 个），需先 close |
| 503 | `resource_unavailable` | 靶场资源不可用（实例未就绪/耗尽） |

---

## 3. 获取提示（会扣分）

```
GET /openapi/v1/challenges/hint?unique_code={unique_code}
```

⚠️ 查看提示后提交 flag 将按比例扣分（`hint_cost_ratio`）。**已通关题目不能再看提示。**

成功响应 `200`：

```json
{
  "unique_code": "web_sql_injection_01",
  "hint": "尝试在登录表单的用户名字段使用单引号测试注入点"
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `unique_code` | string | 题目唯一标识 |
| `hint` | string \| null | 提示内容，无提示时为 null |

业务异常：

| HTTP | code | 触发场景 |
|------|------|----------|
| 404 | `challenge_not_found` | `unique_code` 不存在 |
| 409 | `invalid_state` | 该题已通关，不允许再查看提示 |

---

## 4. 提交 Flag

```
POST /openapi/v1/challenges/submit
Content-Type: application/json
```

请求体：

```json
{
  "unique_code": "web_sql_injection_01",
  "flag": "flag{example_flag_value}"
}
```

| 字段 | 类型 | 必填 | 约束 | 说明 |
|------|------|------|------|------|
| `unique_code` | string | 是 | - | 题目唯一标识 |
| `flag` | string | 是 | 长度 1~4096 | 提交的 flag 值 |

成功响应 `200`：

```json
{
  "correct": true,
  "awarded": 50,
  "cumulative_score": 80,
  "correct_flag_count": 2,
  "total_flag_count": 3,
  "matched_flag_index": 1
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| `correct` | bool | 本次提交是否正确 |
| `awarded` | int | 本次获得分数（错误时为 0） |
| `cumulative_score` | int | 该题累计总得分 |
| `correct_flag_count` | int | 已正确提交的 flag 数 |
| `total_flag_count` | int | 该题 flag 总数 |
| `matched_flag_index` | int \| null | 匹配的 flag 索引（错误时为 null） |

业务异常：

| HTTP | code | 触发场景 |
|------|------|----------|
| 404 | `challenge_not_found` | `unique_code` 不存在 |
| 409 | `duplicate` | 同一 flag（相同 flag_index）重复正确提交，幂等保护 |
| 422 | 框架级验证错误 | `flag` 长度不在 1~4096 |

---

## 5. 关闭题目容器

```
POST /openapi/v1/challenges/close?unique_code={unique_code}
```

| 参数 | 位置 | 类型 | 必填 | 说明 |
|------|------|------|------|------|
| `unique_code` | query | string | 是 | 题目唯一标识 |

成功响应 `200`：

```json
{
  "unique_code": "web_sql_injection_01",
  "closed": true
}
```

业务异常：

| HTTP | code | 触发场景 |
|------|------|----------|
| 404 | `challenge_not_found` | `unique_code` 不存在 |

---

## 统一错误响应格式

```json
{
  "code": "error_code",
  "message": "人类可读的错误描述",
  "detail": {}
}
```

## 通用错误码

| HTTP | code | 触发场景 |
|------|------|----------|
| 404 | `task_not_found` | token 无效/缺失/任务不存在 |
| 404 | `challenge_not_found` | `unique_code` 不在当前任务 |
| 409 | `invalid_state` | 任务已结束（超时/手动停止），或容器上限 |
| 409 | `duplicate` | 同一 flag 重复正确提交 |
| 503 | `resource_unavailable` | 靶场资源不可用 |
| 500 | `internal_error` | 未预期系统错误 |

## 注意事项

1. **VPN**：`container_addr` 需通过 SSLVPN 直连，确保 VPN 已连接再访问题目。
2. **超时**：任务有总时限，超时后所有接口返回 `invalid_state`。
3. **提示扣分**：调用 hint 后该题后续 flag 得分按比例扣减。
4. **幂等**：同一 flag 重复提交返回 `duplicate`，不重复加分。
5. **资源释放**：答题完成务必 close 释放容器。
